package com.example.finalprojecbackend.service;

import com.example.finalprojecbackend.model.MyOrder;
import com.example.finalprojecbackend.model.Product;
import com.example.finalprojecbackend.model.User;
import com.example.finalprojecbackend.repository.orderRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service @AllArgsConstructor
public class orderService {
    public final orderRepository orderrepository;

    public List<MyOrder> get_order(){
        return orderrepository.findAll();
    }
    public void add_order(MyOrder order, User user){
        order.setUserId(user.getId());
        orderrepository.save(order);

    }
    public void update_order (MyOrder order, Integer id){
        MyOrder oldo=orderrepository.findMyOrderByNumber(id);
        oldo.setTime(order.getTime());
        orderrepository.save(oldo);
    }

    public void delete_order(Integer id){
        MyOrder myOrder=orderrepository.getById(id);
        orderrepository.delete(myOrder);
    }


}
