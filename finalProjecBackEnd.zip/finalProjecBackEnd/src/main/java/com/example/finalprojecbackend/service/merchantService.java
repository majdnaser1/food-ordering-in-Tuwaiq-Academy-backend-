package com.example.finalprojecbackend.service;

import com.example.finalprojecbackend.model.Customer;
import com.example.finalprojecbackend.model.Merchant;
import com.example.finalprojecbackend.repository.authUserRepository;
import com.example.finalprojecbackend.repository.merchantRepository;
import com.example.finalprojecbackend.repository.productRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor @Service
public class merchantService {
    public final merchantRepository merchantrepository;
    private final authUserRepository authuserRepository;
    public final productRepository productrepository;



    public List<Merchant> get_merchant(){
        return merchantrepository.findAll();
    }
    public void add_merchant(Merchant merchant) {
       merchantrepository.save(merchant);

        }

    public void update_merchant(Merchant merchant, Integer id){
        Merchant oldm=merchantrepository.findMerchantById(id);
        oldm.setFullName(merchant.getFullName());
        oldm.setLocation(merchant.getLocation());
        merchantrepository.save(oldm);
    }
    public void delete_merchant(Integer id){
        Merchant myMerchant=merchantrepository.getById(id);
        merchantrepository.delete(myMerchant);
    }









}
