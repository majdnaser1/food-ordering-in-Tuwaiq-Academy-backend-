package com.example.finalprojecbackend.service;

import com.example.finalprojecbackend.dto.ApiException;
import com.example.finalprojecbackend.dto.RegisterForm;
import com.example.finalprojecbackend.model.Customer;
import com.example.finalprojecbackend.model.Merchant;
import com.example.finalprojecbackend.model.User;
import com.example.finalprojecbackend.repository.authUserRepository;
import com.example.finalprojecbackend.repository.customerRepository;
import com.example.finalprojecbackend.repository.merchantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class authUserService {

    private final authUserRepository authuserRepository;
    private final merchantRepository merchantrepository;
    private final customerRepository customerrepository;

    public void register(RegisterForm registerForm) {
        String hashedPassword=new BCryptPasswordEncoder().encode(registerForm.getPassword());
        registerForm.setPassword(hashedPassword);
        User userS=new User(null,registerForm.getUsername(),registerForm.getPassword(),registerForm.getRole());
        User newUser=authuserRepository.save(userS);
        if(registerForm.getRole().equals("merchant")){
            Merchant merchant=new Merchant(null,registerForm.getFullName(),registerForm.getLocation(),newUser.getId());
            merchantrepository.save(merchant);
        }else {
            Customer customer=new Customer(null,registerForm.getName(),registerForm.getPhoneNumber(),newUser.getId());
            customerrepository.save(customer);
        }

    }

}