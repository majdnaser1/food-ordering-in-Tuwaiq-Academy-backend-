package com.example.finalprojecbackend.controller;
import com.example.finalprojecbackend.dto.ApiResponse;
import com.example.finalprojecbackend.model.Customer;
import com.example.finalprojecbackend.service.customerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/v1/customer")
public class customerController {
    public final customerService customerservice;


    @GetMapping
    public ResponseEntity<List> getCustomer(){
        List<Customer> customer=customerservice.get_customer();
        return ResponseEntity.status(200).body(customer);
    }
    @PostMapping
    public ResponseEntity<ApiResponse> addCustomer( @RequestBody @Valid Customer customer){
        customerservice.add_customer(customer);
        return ResponseEntity.status(200).body(new ApiResponse("customer added",200));
    }
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse> updateCustomer(@RequestBody @Valid Customer customer,@PathVariable Integer id){
        customerservice.update_customer(customer,id);
        return ResponseEntity.status(200).body(new ApiResponse("Customer updated,",200));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteCustomer(@PathVariable Integer id){
        customerservice.delete_customer(id);
        return ResponseEntity.status(200).body(new ApiResponse("customer deleted",200));

    }



}
