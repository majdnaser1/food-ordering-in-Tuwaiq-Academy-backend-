package com.example.finalprojecbackend.controller;

import com.example.finalprojecbackend.dto.ApiResponse;
import com.example.finalprojecbackend.model.MyOrder;
import com.example.finalprojecbackend.model.User;
import com.example.finalprojecbackend.service.orderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("api/v1/order")
public class orderController {
    public final orderService orderservice;

    @GetMapping
    public ResponseEntity <List> getOrder(){
        List <MyOrder> order= orderservice.get_order();
        return ResponseEntity.status(200).body(order);
    }
    @PostMapping
    public ResponseEntity<ApiResponse> addOrder(@RequestBody MyOrder order, @AuthenticationPrincipal User user){
        orderservice.add_order(order,user);
        return ResponseEntity.status(200).body(new ApiResponse("order added",200));
    }
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse> updateOrder(@RequestBody MyOrder order, @PathVariable Integer id){
        orderservice.update_order(order,id);
        return ResponseEntity.status(200).body(new ApiResponse("order updated",200));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteOrder(@PathVariable Integer id){
        orderservice.delete_order(id);
        return ResponseEntity.status(200).body(new ApiResponse("Order deleted",200));
    }






}
