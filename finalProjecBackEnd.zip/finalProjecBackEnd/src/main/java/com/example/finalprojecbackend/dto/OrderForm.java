package com.example.finalprojecbackend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor @Data
public class OrderForm {
    private String fullName;
    private String location;
    private String name;
    private String size;
    private String productDetails;
    private Integer price;
    private Integer time;

}
