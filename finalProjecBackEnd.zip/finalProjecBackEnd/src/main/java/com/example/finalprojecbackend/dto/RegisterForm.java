package com.example.finalprojecbackend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@AllArgsConstructor @Data
public class RegisterForm {
    @NotEmpty(message = "username can't be empty")
    private String username;
    @NotEmpty(message = "password can't be empty")
    private String password;
    @Pattern(regexp ="(merchant|customer)",message = "Role must be in merchant or customer only")
    private String role;
    private String name;
    private String phoneNumber;
    private String fullName;
    private String location;

}
