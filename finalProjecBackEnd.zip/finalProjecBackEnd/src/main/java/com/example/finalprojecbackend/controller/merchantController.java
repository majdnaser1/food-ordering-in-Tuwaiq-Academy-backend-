package com.example.finalprojecbackend.controller;

import com.example.finalprojecbackend.dto.ApiResponse;
import com.example.finalprojecbackend.model.Merchant;
import com.example.finalprojecbackend.service.merchantService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
@RestController
@RequiredArgsConstructor
@RequestMapping("api/v1/merchant")
public class merchantController {
    public final merchantService merchantservice;
    @GetMapping
    public ResponseEntity<List> getMerchant(){
        List<Merchant> customer=merchantservice.get_merchant();
        return ResponseEntity.status(200).body(customer);
    }
    @PostMapping
    public ResponseEntity<ApiResponse> addMerchant(@RequestBody @Valid Merchant merchant){
        merchantservice.add_merchant(merchant);
        return ResponseEntity.status(200).body(new ApiResponse("merchant added",200));
    }
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse> updateMerchant(@RequestBody @Valid Merchant merchant ,@PathVariable Integer id){
        merchantservice.update_merchant(merchant,id);
        return ResponseEntity.status(200).body(new ApiResponse("merchant updated,",200));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteMerchant(@PathVariable Integer id){
        merchantservice.delete_merchant(id);
        return ResponseEntity.status(200).body(new ApiResponse("merchant deleted",200));

    }
}
