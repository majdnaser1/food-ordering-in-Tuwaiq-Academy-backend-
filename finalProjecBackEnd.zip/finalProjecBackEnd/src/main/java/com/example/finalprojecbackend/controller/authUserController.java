package com.example.finalprojecbackend.controller;

import com.example.finalprojecbackend.dto.ApiResponse;
import com.example.finalprojecbackend.dto.RegisterForm;
import com.example.finalprojecbackend.service.authUserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/auth")
public class authUserController {
    private final authUserService authuserservice ;


    @PostMapping("/register")
    public ResponseEntity register(@RequestBody @Valid RegisterForm registerForm){
        authuserservice.register(registerForm);
        return ResponseEntity.status(201).body(new ApiResponse("New user registered !",201));
    }



}
