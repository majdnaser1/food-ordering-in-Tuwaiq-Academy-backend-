package com.example.finalprojecbackend.service;

import com.example.finalprojecbackend.model.Customer;
import com.example.finalprojecbackend.model.User;
import com.example.finalprojecbackend.repository.authUserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MyUserDetailsService implements UserDetailsService {

    public final authUserRepository authuserrepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = authuserrepository.findUserByUsername(username);

        if (user==null) {
            throw new UsernameNotFoundException("Invalid username or password");
        }
        return user;
    }

}

