package com.example.finalprojecbackend.service;

import com.example.finalprojecbackend.model.*;
import com.example.finalprojecbackend.repository.authUserRepository;
import com.example.finalprojecbackend.repository.merchantRepository;
import com.example.finalprojecbackend.repository.productRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class productService {
    public final productRepository productrepository;
    public final authUserRepository authUserrepository;
    public final merchantRepository merchantRepository;



    public List<Product> get_product(){
        return productrepository.findAll();
    }
    public void add_product(Product product , User user) throws Exception {
        product.setUserid(user.getId());
        productrepository.save(product);

    }

    public void update_product(Product product, Integer id){
        Product oldp=productrepository.findProductById(id);
        oldp.setName(product.getName());
        oldp.setProductDetails(product.getProductDetails());
        oldp.setSize(product.getSize());
        oldp.setPrice(product.getPrice());
        productrepository.save(oldp);
    }

    public void delete_product(Integer id){
        Product myProduct=productrepository.getById(id);
        productrepository.delete(myProduct);
    }
}
