package com.example.finalprojecbackend.service;

import com.example.finalprojecbackend.model.Customer;
import com.example.finalprojecbackend.model.Product;
import com.example.finalprojecbackend.repository.authUserRepository;
import com.example.finalprojecbackend.repository.customerRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service@AllArgsConstructor
public class customerService {

    public final customerRepository customerrepository;
//    public final authUserRepository authcustomerRepository;

    public List<Customer> get_customer(){
        return customerrepository.findAll();
    }

    public void add_customer(Customer customer){
        customerrepository.save(customer);

    }
    public void update_customer(Customer customer, Integer id){
        Customer oldc=customerrepository.findCustomerById(id);
        oldc.setName(customer.getName());
        oldc.setPhoneNumber(customer.getPhoneNumber());
        customerrepository.save(oldc);
    }
    public void delete_customer(Integer id){
        Customer myCustomer=customerrepository.getById(id);
        customerrepository.delete(myCustomer);
    }


}
