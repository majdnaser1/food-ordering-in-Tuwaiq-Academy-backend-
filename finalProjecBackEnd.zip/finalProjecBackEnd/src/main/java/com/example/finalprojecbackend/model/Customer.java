package com.example.finalprojecbackend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.Collection;
import java.util.Collections;

@AllArgsConstructor @NoArgsConstructor @Data
@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(columnDefinition ="varchar(20)")
    private String name;
    @Column(columnDefinition ="varchar(10) unique")
    @Size(min = 10,max = 10 ,message = "Phone number must be 10 characters")
    //  @Pattern(regexp = "^(05)([0-9])$",message = "please enter right phone number")
    private String phoneNumber;
    private Integer userId;



}

