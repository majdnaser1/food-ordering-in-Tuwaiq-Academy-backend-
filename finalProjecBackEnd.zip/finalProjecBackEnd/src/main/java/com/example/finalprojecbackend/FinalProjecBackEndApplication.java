package com.example.finalprojecbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalProjecBackEndApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinalProjecBackEndApplication.class, args);
    }

}
