package com.example.finalprojecbackend.controller;

import com.example.finalprojecbackend.dto.ApiResponse;
import com.example.finalprojecbackend.model.Product;
import com.example.finalprojecbackend.model.User;
import com.example.finalprojecbackend.service.productService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("api/v1/product")
public class productController {
    public final productService productservice;

    @GetMapping("/get")
    public ResponseEntity<List> getProduct(){
        List <Product> product= productservice.get_product();
        return ResponseEntity.status(200).body(product);
    }
    @PostMapping("/merchant")
    public ResponseEntity<ApiResponse> addProduct(@RequestBody Product product, @AuthenticationPrincipal User user) throws Exception {
        productservice.add_product(product,user);
        return ResponseEntity.status(200).body(new ApiResponse("product added",200));
    }
    @PutMapping("/merchant/{id}")
    public ResponseEntity<ApiResponse> updateProduct(@RequestBody Product product,@PathVariable Integer id){
        productservice.update_product(product,id);
        return ResponseEntity.status(200).body(new ApiResponse("product updated",200));
    }
    @DeleteMapping("/merchant/{id}")
    public ResponseEntity<ApiResponse> deleteProduct(@PathVariable Integer id){
        productservice.delete_product(id);
        return ResponseEntity.status(200).body(new ApiResponse("product deleted",200));
    }



}
